import java.util.*;

class Armstg_Perfect
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a number");
int n=sc.nextInt();
int sum=0;
int i=0;
int t=n;
while(i<n)
{
int r=n%10;
sum=sum+(r*r*r);
n=n/10;
}
if(sum==t)
{
System.out.println("It is an amstrong number");
}
else
{
System.out.println("It is not an amstrong number");
}


int s=0;
for(int j=1;j<t;j++)
{
if(t%j==0)
{
s=s+j;
}
}
if(s==t)
{
System.out.println("It is a perfect number");
}
else
{
System.out.println("It is not a perfect number");
}
}
}
