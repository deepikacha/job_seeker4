class Area
{
public static void main(String[] args)
{
double r=30;
double pi=3.14;
System.out.println("area of circle :"+(pi*r*r));
System.out.println("cube :"+(r*r*r));
}
}