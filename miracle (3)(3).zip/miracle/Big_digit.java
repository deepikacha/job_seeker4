import java.util.*;

class Big_digit
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a number");
int n=sc.nextInt();
int big=0;
while(n>0)
{
int r=n%10;
 
big=Math.max(r,big);
n=n/10;

}
System.out.println("biggest digit in the number is : "+big);
}
}


