import java.util.*;
class Patterns3
{
public static void main(String[] args) {
 
int t=5;
int number=1;
for(int i=0;i<5;i++) {
for(int s=1;s<=t;s++) {
System.out.print(" ");
}
number=1;
for(int j=0;j<=i;j++) {

if(i!=2 && i!=1)
{
System.out.print(number+" ");
number=number * (i-j)/(j+1);
}
}
System.out.println();
t--;
}

}

}
