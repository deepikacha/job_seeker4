import java.util.*;
class Series2
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a number n");
int n=sc.nextInt();
double sum=1;
for(int i=1;i<=n;i++)
{
sum=sum+(double)1/(2*i);
}
System.out.println("sum of series : "+sum);
}
}