import java.util.*;

class Altsum
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter a  number ");
int n=sc.nextInt();
int i=1;
int f=0;
int sum=0;
while(i<n)
{
int r=n%10;
if(f%2==0)
{
sum=sum+r;
}
n=n/10;
f++;
}
System.out.println("sum of alternate digits :"+sum);


}
}