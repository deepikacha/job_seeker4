import java.util.*;

class  Nevenno
{
public static void main(String[] args)
{
Scanner sc=new  Scanner(System.in);
System.out.println("enter a number");
int n=sc.nextInt();
int i=0;
int c=0;
while(c!=n)
{
if(i%2==0)
{
System.out.println(i);
c++;
}
i++;
}

}
}

