import java.util.*;

class Occuerence
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a number");
int n=sc.nextInt();
int t=n;
int big=0;
int c=0;
System.out.println("enter  a digit");
int x=sc.nextInt();
while(n>0)
{
int r=n%10;
if(x==r)
{
c++;
}
n=n/10;

}
System.out.println("The number of occuerence of "+x+"in "+t+"is : "+c);
}
}

