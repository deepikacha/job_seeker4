import java.util.*;
class prev_char
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a String");
String s=sc.nextLine();
String s1=s.replace(s.charAt(0),s.charAt(s.length()-1));

for(int i=0;i<s.length();i++)
{
if(s.charAt(i)==' ')
{

s1=s1.replace(s.charAt(i+1),s.charAt(i-1));
}
}
System.out.println(s1);
}
}
