import java.util.*;

class withDrawException extends Exception
{
public withDrawException(String s)
{
super(s);
}

}

class lowBalanceException extends Exception
{
public lowBalanceException(String str)
{
super(str);
}
}

class InvalidCredentialsException extends Exception
{
public InvalidCredentialsException(String msg)
{
super(msg);
}
}

public class Bank
{
static double bal=10000.0;
public static void main(String[] args) throws InvalidCredentialsException,withDrawException,lowBalanceException
{
Scanner sc=new Scanner(System.in);

while(true)
{
System.out.println("1.Deposit  2.WithDraw 3.Balance  4.exit");

int option=sc.nextInt();
switch(option)
{
case 1:
     System.out.println("enter some amount to deposit ");
     int d=sc.nextInt();
     if(d<500)
     {
       throw new withDrawException("user,please enter more than 500");
     }
     else
     {
          bal=bal+d;
        System.out.println("new balance : "+bal);
     }
  break;

case 2:
       System.out.println("enter some amount to Withdraw ");
       int m=sc.nextInt();
       if(m<bal)
        {
          System.out.println("amount :"+m);
          System.out.println("current balance :"+(bal-m));
         }
        else 
       {
        throw new lowBalanceException(" In sufficient balance ");
       }
       break;

case  3:
       String un="username@bank";
       String pass="Abc@123";
        
        System.out.println("please enter user name");
        String u=sc.next();
        System.out.println("Please enter password");
        String p=sc.next();
        if(u.equals(un) && p.equals(pass))
        {
          System.out.println(bal);
         }
         else
          {
             throw  new InvalidCredentialsException("please enter valid credentials");
            }
           break;
case 4:
      System.out.println("Thankyou");
      System.exit(0);

default:
     System.out.println("please enter between 1 to 4");
}
}
}
}