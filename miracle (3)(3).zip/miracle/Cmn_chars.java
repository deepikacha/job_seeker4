import java.util.*;

class Cmn_chars
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a string:");
String s=sc.nextLine();
System.out.println("enter another string");
String s1=sc.nextLine();
for(int i=0;i<s.length();i++)
{
for(int j=0;j<s1.length();j++)
{
if(s.charAt(i)==s1.charAt(j))
{
System.out.println(s.charAt(i));
}
}

}
}
}