import java.util.*;
class userdefined_Length
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
String s=sc.nextLine();
int i=0;
for(char c:s.toCharArray())
{
i++;
}
}
System.out.println("length of string :"+i);

}