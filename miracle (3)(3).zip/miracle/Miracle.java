class Miracle
{
public static void main(String[] args)
{
System.out.println("Miracle world");
}
} 