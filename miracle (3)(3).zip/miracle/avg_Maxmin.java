import java.util.*;

class avg_Maxmin
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter numbers");
int l=0;
int s=99999999;
int sum=0;
for(int i=0;i<10;i++)
{
int j=sc.nextInt();
sum=sum+j;
l=Math.max(j,l);
s=Math.min(j,s);
}
System.out.println("Average of the numbers is :"+(sum/10));
System.out.println("Maximum of numbers is : "+l);
System.out.println("Minimum of numbers is : "+s);
}
}