import java.util.*;

class Series1
{
public static void main(String[] args)
{

Scanner sc=new Scanner(System.in);
System.out.println(" enter a number n");
int n=sc.nextInt();
double  sum=0;
for(int i=1;i<=n;i++)
{
sum=sum+(double)1/(i);

}
System.out.println("Sum of  series is :"+sum);
}
}
