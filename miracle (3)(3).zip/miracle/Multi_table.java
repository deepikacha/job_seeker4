

class Multi_table
{
public static void main(String[] args)
{

for(int i=1;i<=10;i++)
{
System.out.println("multiplication table of "+i);
for(int j=1;j<=12;j++)
{
System.out.println(i+" * "+j+" = "+i*j);
}
System.out.println("-------------------------------");
} 
}
}