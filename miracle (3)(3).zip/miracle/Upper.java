import java.util.*;
 
class Vowels_consonants
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a character");
String s=sc.nextLine();
int c=0;
int ct=0;
for(int i=0;i<s.length();i++)
{
if(s.charAt(i)=='a'||s.charAt(i)=='e'|| s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u')
{
c++;
}
else
{
ct++;


}
}
System.out.println("number of vowels : "+c);
System.out.println("number of vowels : "+ct);