import java.util.*;

class CAl
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a number: ");
int c=sc.nextInt();
switch(c)
{
case 1:
System.out.println("enter a:");
int a=sc.nextInt();
System.out.println("enter b:");
int b=sc.nextInt();
System.out.println(a+b);

case 2:
System.out.println("enter a:");
int a1=sc.nextInt();
System.out.println("enter b:");
int b1=sc.nextInt();
System.out.println(a1-b1);

case 3:
System.out.println("enter c");
int c=sc.nextInt();
System.out.println("enter d");
int d=sc.nextInt();
System.out.println(c*d);

case 4:
System.out.println("enter c");
int c1=sc.nextInt();
System.out.println("enter d");
int d1=sc.nextInt();
System.out.println(c1/d1);

default:
System.out.prinln("please enter a valid input");

}
}
}