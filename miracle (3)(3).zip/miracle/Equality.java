import java.util.*;

class Equality
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a number");
int n=sc.nextInt();
int t=n%10;
System.out.println("enter  a digit");
int x=0;
int c=0;
while(n>0)
{
int r=n%10;

n=n/10;
if(r==t)
{
c=c+1;
}
x++;
}
if(c==x)
{
System.out.println("yes all are equal");
}
else
{
System.out.println("no,all digits are not equal");
}
}
}
