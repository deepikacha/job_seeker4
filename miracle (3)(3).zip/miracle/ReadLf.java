import java.io.*;

class ReadLf
{
public static void main(String[] args) throws IOException,FileNotFoundException
{
FileInputStream fin=new FileInputStream("D:\\prac\\miracle\\f.txt");
int i=0;
while((i=fin.read())!=-1)
{
System.out.print((char)i);
}
}
}