import java.util.*;

class  Nprime_no
{
public static void main(String[] args)
{
Scanner sc=new  Scanner(System.in);
System.out.println("enter a number");
int n=sc.nextInt();
int c=0;
int count=0;
while(c!=n)
{
int i=1;
int j=1;
while(i<=n)
{
while(j<=n)
{
if(i%j==0)
{
count++;
}
}
if(count==2)
{
System.out.println(i);
}
}
c++;
}
}
}

