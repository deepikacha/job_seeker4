import java.util.*;

class Series3
{
static int fact(int a)
{
int x=1;
for(int j=1;j<=a;j++)
{
x=x*j;
}
return x;
}

public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter x :");
int x=sc.nextInt();
System.out.println("enter n : ");
int n=sc.nextInt();
double sum=1;
for(int i=1;i<=n;i++)
{
sum=sum+(double)(Math.pow(x,i)/fact(i));
}
System.out.println("sum of number "+sum);
}
}