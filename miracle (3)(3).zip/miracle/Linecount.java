import java.io.*;
import java.util.*;

class Linecount
{
public static void main(String[] args) throws IOException,FileNotFoundException
{
FileInputStream fin=new FileInputStream("D:\\prac\\miracle\\f.txt");
Scanner sc=new Scanner(fin,"UTF-8");
int c=0;
while(sc.hasNextLine())
{
String s=sc.nextLine();
c++;
}
System.out.println("The number of lines in the file : "+c);
}
}
