import java.util.*;

class Y_Salary
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter your salary");
int your_salary=sc.nextInt();
System.out.println("your salary is : "+your_salary);
}
}