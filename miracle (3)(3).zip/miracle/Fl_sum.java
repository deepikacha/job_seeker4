import java.util.*;

class Fl_sum

{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a number ");
int n=sc.nextInt();
int i=0;
int sum=0;
int r=0;
while(i<n)
{
r=n%10;
if(i==0)
{
sum=sum+r;
}
n=n/10;
i++;
}
sum=sum+r;
System.out.println("sum of first and last digit :"+(sum-1));


}
}
