import java.util.*;

class time_Conversion
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter time in hours");
int hours=sc.nextInt();
System.out.println("Equivalent seconds  for the"+hours+" hours is :" +(hours*3600) +"secs");
}
}