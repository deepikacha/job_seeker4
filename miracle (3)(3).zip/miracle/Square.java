class Square
{
public static void main(String[] args)
{
int j;
j=10;
System.out.println(j);
System.out.println("square :" +j*j);
System.out.println("cube :"+j*j*j);

}
}