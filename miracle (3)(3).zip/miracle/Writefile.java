import java.io.*;

class Writefile
{
public static void main(String[] args)
{
try
{
File f1=new File("D:\\prac\\miracle\\f2.txt");
f1.createNewFile();
}
catch(Exception e)
{
System.out.println(e);
}
}
}