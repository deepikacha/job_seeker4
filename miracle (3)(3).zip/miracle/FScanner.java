import java.io.*;
import java.util.*;

class FScanner
{
public static void main(String[] args) throws IOException,FileNotFoundException
{
FileInputStream fin=new FileInputStream("D:\\prac\\miracle\\f.txt");
Scanner sc=new Scanner(fin,"UTF-8");
while(sc.hasNextLine())
{
String s=sc.nextLine();
System.out.println(s);
}
}
}
