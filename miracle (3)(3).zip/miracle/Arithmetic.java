class Arithmetic
{
public static void main(String args[])
{
int a=10;
int b=30;
System.out.println("addition : "+(a+b));
System.out.println("substraction  :"+(a-b));
System.out.println("multiplication :"+(a*b));
System.out.println("division :"+(a/b));
System.out.println("modulo division  :" +(a%b));
}
}