import java.util.*;
class Commn
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);

String s1=sc.nextLine();
String s2=sc.nextLine();
String s3="";
String s4="";
for(int i=0;i<s1.length();i++)
{
for(int j=0;j<s2.length();j++)
{
if(s1.charAt(i)!=s2.charAt(j))
{
  s3=s3+s1.charAt(i);
  s4=s4+s2.charAt(j);
}

}
}
System.out.println(s3);
System.out.println(s4);
}
}