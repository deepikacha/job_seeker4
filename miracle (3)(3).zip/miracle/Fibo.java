import  java.util.*;

class Fibo
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a number");
int n=sc.nextInt();
System.out.println("fibonacci series of ");
int f1=0;
System.out.println(f1);
int f2=1;
System.out.println(f2);
int f3;
for(int i=1;i<=n;i++)
{

f3=f2+f1;
f1=f2;
f2=f3;
System.out.println(f3);
}
}
}