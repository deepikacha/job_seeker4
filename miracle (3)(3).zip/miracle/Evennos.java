import java.util.*;

class Evennos
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();

for(int i=0;i<n;i++)
{
if(i%2==0)
{
System.out.println("even");
}
else
{
System.out.println("odd");
}
}
int j=0;
while(j>=n)
{
if(j%2==0)
{
System.out.println("even");
}
else
{
System.out.println("odd");
}
j++;
}
do
{
if(k%2==0)
{
System.out.println("even");
}
else
{
System.out.println("odd");
}
k++;
}
while(k<=n)
}
}