import java.util.*;

class Student
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
String name=sc.nextLine();
int roll_no=sc.nextInt();
Student s=new Student();
s.name="jhon";
s.roll_no=2;
}
}