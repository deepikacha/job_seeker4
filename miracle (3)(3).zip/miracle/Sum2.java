import java.util.*;

class Sum2
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter numbers :");
int n=sc.nextInt(); 
int s=0;
for(int i=1;i<=n;i++)
{
s=s+i;
}
System.out.println(s);
}
}







































































