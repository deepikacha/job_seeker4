import java.util.*;

class palindrome_string
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a string");
String s=sc.nextLine();
String s1="";
int c=0;
for(int i=s.length()-1;i>=0;i--)
{
s1=s1+s.charAt(i);
}
for(int j=0;j<s.length();j++)
{
if(s.charAt(j)==s1.charAt(j))
{
c++;
}
}
if(c==s.length())
{
System.out.println("It is a palindrome");

}
else
{
System.out.println("It is not a palindrome");
}
}
}