import java.util.*;
class rev_word
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
String s=sc.nextLine();
for(int i=s.length()-1;i>=0;i--)
{
if(s.charAt(i)==' ')
{
System.out.println("");
}
else
{
System.out.println(s.charAt(i));

}

}