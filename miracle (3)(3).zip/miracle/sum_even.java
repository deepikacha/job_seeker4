import java.util.*;
class sum_even
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int s=0;
for(int i=0;i<n;i++)
{
if(i%2==0)
{
s=s+i;
}
}
System.out.println(s);
}
}