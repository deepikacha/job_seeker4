import java.io.*;
import java.util.*;

class RSLine
{
public static void main(String[] args) throws IOException,FileNotFoundException
{
FileInputStream fin=new FileInputStream("D:\\prac\\miracle\\f.txt");
Scanner sc=new Scanner(fin,"UTF-8");
int c=0;
Scanner s=new Scanner(System.in);
System.out.println("enter a line");
int x=s.nextInt();
while(sc.hasNextLine() && c==x)
{
if(c==x)
{
String str=sc.nextLine();
System.out.println(str);
}
 
c++;
}
 
}
}
